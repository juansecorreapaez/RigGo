# RigGO 12.4.3

Build: `2026-10-14-1243-A1`. Base: la entrega RigGO 12.4.2 del entorno del usuario.

## Cambios de esta entrega

- Ingles para los textos de la interfaz, incluidos titulos y descripciones de tarjetas, saludo, estados dinamicos, formularios, accesibilidad, etiquetas CSS de tablas moviles, dialogos y etiquetas/valores predeterminados de reportes. La seleccion de espanol sigue disponible y se conserva la preferencia por usuario. Nombres, descripciones, comentarios y campos en edicion se mantienen como datos del usuario; los valores canonicos de estados y opciones no cambian.
- La aplicacion acepta `@nabors.com` y `@sanad.com` en ingreso, creacion de acceso, recuperacion de contrasena, creacion administrativa de usuarios y miembros de grupos de distribucion. Los destinatarios de Daily Move Update y correo de prueba admiten SANAD. La habilitacion de la cuenta y los permisos existentes siguen siendo obligatorios.
- Renderer de correo 6: un correo pendiente de una version anterior se vuelve a preparar con sus etiquetas, grafica y PDF actuales; los correos ya enviados conservan su copia original.

No se ha modificado ni desplegado codigo en Supabase. La fuente de `riggo-admin-users` y `riggo-send-email` no esta en este repositorio. Las pruebas de esas funciones usan respuestas simuladas; cualquier restriccion de dominio en las funciones, Auth o la base de datos real debe verificarse antes de declarar SANAD habilitado de extremo a extremo. Ver `docs/SANAD_BACKEND_CHECK.md`.

## Cambios

- Inglés y español: el primer ingreso autorizado pide elegir idioma; los ingresos siguientes recuperan la preferencia. Un selector en la barra superior permite cambiarla. La preferencia se guarda por usuario en Supabase Auth y se conserva localmente mientras no haya conexión. Los pendientes se sincronizan únicamente bajo la cuenta correspondiente.
- Se traducen las pantallas de planificación, ejecución, administración y Performance, mensajes y reportes generados. Los nombres, comentarios, descripciones, datos del Excel e identificadores operativos conservan el contenido aportado por el usuario. Cambiar idioma conserva los campos en edición y los estados de ejecución.
- Arranque compatible con versiones superiores de IndexedDB y almacenes faltantes; reintento limitado para errores transitorios, identificación del error y reintento sin borrar planes, evidencias ni colas. El arranque espera a que terminen de cargar los módulos y no depende de completar una actualización del Service Worker.
- M48 distingue período real, tiempo de operación desde la liberación real, tiempo del plan al corte y retraso de liberación. Ejemplo: liberación planificada 12:00, real 21:00 y corte 00:00: 3 horas reales, 12 horas del plan y 9 horas de retraso. La línea base se conserva.
- Transporte muestra cargadas acumuladas, pendientes de salir, en tránsito y posicionadas. Al terminar 54 cargas: 54 acumuladas, 0 pendientes de salir, 0 en tránsito y 54 posicionadas. Se conserva RM físico = posicionadas / total y los ajustes del supervisor.

## Publicar en Cloudflare Pages

1. Publicar el contenido de la raíz con `index.html`, `sw.js`, `version.json`, `_headers`, `manifest.webmanifest` y `assets/`. No requiere compilación ni instalación de paquetes.
2. Mantener el origen/dominio existente. No borrar los datos del sitio para actualizar.
3. Comprobar el título **RigGO · 12.4.3** y build `2026-10-14-1243-A1`.
4. Con una cuenta autorizada, elegir idioma, salir y volver; comprobarlo también en otro dispositivo. Cambiar idioma durante una edición y verificar el reporte.
5. Validar el arranque en la instalación Edge afectada y verificar M48, transporte, desplazamiento, fotos/firma y operación offline antes de extender el despliegue.

La preferencia usa los metadatos de Supabase Auth del usuario (`riggo_language`, `riggo_language_selected`, `riggo_language_updated_at`). La actualizacion de los archivos estaticos no requiere SQL ni nuevos permisos administrativos. Esta entrega no se desplego ni se enviaron correos reales. Para el servidor SANAD, seguir la verificacion indicada arriba.

## Validación

Vease `docs/VALIDATION_12.4.3.md`: 80 comprobaciones locales, 41 superficies revisadas durante el diagnostico de traduccion y verificacion especifica de los ultimos textos encontrados. Se ejecutan el codigo y almacenamiento reales con servicios externos aislados. Los perfiles Edge/Brave de Chromium no sustituyen probar las instalaciones reales afectadas.
