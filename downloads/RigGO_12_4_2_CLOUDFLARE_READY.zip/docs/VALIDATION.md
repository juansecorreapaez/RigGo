# Validación RigGO 12.4.2

Build: `2026-10-14-1242-A1`. Base: paquete local RigGO 12.4.1.

Se ejecutan JavaScript, IndexedDB, PWA y motores PDF/gráficas reales en Chromium. Las APIs de Supabase, autenticación y correo están aisladas o simuladas. No se utiliza una cuenta real ni se envían correos, se ejecuta SQL o se publica una versión durante estas pruebas.

## Operación conservada

Los 29 grupos de `scripts/smoke_release.py` cubren transporte al corte, historial de reinicio de cargas, interpolación por horas del plan, porcentajes manuales, PDF y correo congelado, actualización de correos pendientes, evidencias y separación por corrida, fin operativo, desplazamiento táctil y perfiles de agente de usuario Edge/Brave. Los correos enviados no se modifican.

## Idioma y almacenamiento

`scripts/validate_1242.py` comprueba la pregunta inicial, guardado de inglés en la cuenta, retorno y recarga sin repetir la pregunta, recuperación desde un dispositivo nuevo, preferencias independientes entre usuarios, cambios rápidos, conservación de campos en edición y de valores canónicos, trabajo offline y sincronización únicamente bajo el propietario de la preferencia.

También comprueba separación de horas reales y planificadas, navegación/estado traducidos, compatibilidad con una base IndexedDB de versión superior, reparación de almacenes faltantes sin perder una fila pendiente, recuperación de un error transitorio y reintento después de permitir almacenamiento bloqueado. Los 29 escenarios completaron sin errores de página no capturados.

Los 29 grupos operativos, los 29 de idioma/almacenamiento y la actualización PWA completaron correctamente (59 comprobaciones).

La actualización real de Service Worker de 12.4.1 a 12.4.2 se comprobó con posterior arranque sin conexión, preservando firma, almacenamiento local y preferencia por usuario.

Se revisan juntos escritorio y móvil: selección inicial, avance en inglés y transporte con selector superior. Los defectos encontrados se corrigen en una tanda; se permite una ronda de confirmación.

## Reproducción

```sh
python scripts/smoke_release.py --site . --output /tmp/riggo-1242-operation
python scripts/validate_1242.py --site . --output /tmp/riggo-1242-language
```

Las pruebas requieren Python 3, Playwright y Chromium. Los resultados JSON se guardan en la carpeta de salida indicada. Usar el mismo origen al publicar para conservar el almacenamiento de los dispositivos.

## Límites prácticos

Un perfil de agente de usuario Edge no sustituye una instalación real de Edge ni las políticas del teléfono o red corporativa. La captura recibida no identifica la causa exacta del error de ese dispositivo. La corrección reproduce y resuelve errores de versión/esquema y errores transitorios de almacenamiento; un bloqueo persistente de almacenamiento requiere permitirlo en el navegador y usar Reintentar.

La persistencia entre dispositivos se prueba contra una API de cuenta simulada, usando la API Auth de Supabase (`PUT /auth/v1/user` con `{data: ...}`), ligada al token de la sesión que inició el guardado. El piloto real debe comprobar ese flujo con una cuenta autorizada. La preferencia no cambia permisos ni requiere migración SQL; usa metadatos del propio usuario autenticado.

No se habilita SANAD ni se modifica la separación por compañías en esta versión.
