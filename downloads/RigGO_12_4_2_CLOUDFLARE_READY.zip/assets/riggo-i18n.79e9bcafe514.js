/* Translation applies to authored copy. Template substitutions (user data) stay verbatim. */
(() => {
  'use strict';
  let language = /^en\b/i.test(navigator.language || '') ? 'en' : 'es';
  const missing = new Set(), catalog = window.RigGOTranslations || {};
  const normalize = s => String(s).replace(/\s+/g, ' ').trim();
  function translated(key) {
    if (Object.prototype.hasOwnProperty.call(catalog, key)) return catalog[key];
    const lower=key.toLocaleLowerCase('es');
    if (Object.prototype.hasOwnProperty.call(catalog, lower)) {
      const value=catalog[lower];
      return key===key.toLocaleUpperCase('es') ? value.toUpperCase() : value;
    }
    if(/[A-Za-zÁÉÍÓÚáéíóúñÑ]/.test(key))missing.add(key); return null;
  }
  function t(value) {
    if(language !== 'en' || typeof value !== 'string' || !value.trim()) return value;
    const key=normalize(value), result=translated(key);
    return result===null?value:value.replace(value.trim(),result);
  }
  function pattern(text) {
    if(language !== 'en')return text;
    const tokens=[];
    const skeleton=text.replace(/\uE000(\d+)\uE001/g,match=>{tokens.push(match);return `{{${tokens.length-1}}}`});
    const key=normalize(skeleton),result=translated(key);
    if(result===null)return text;
    const converted=result.replace(/\{\{(\d+)\}\}/g,(_,i)=>tokens[Number(i)]||'');
    return skeleton.replace(skeleton.trim(),converted);
  }
  function markup(source) {
    // An option's canonical value must never change when its label is translated.
    source=source.replace(/<option\b([^>]*)>([^<]*)<\/option>/gi,(all,attributes,body)=>
      /\bvalue\s*=/.test(attributes)?all:`<option${attributes} value="${body.replace(/&/g,'&amp;').replace(/"/g,'&quot;')}">${body}</option>`);
    let protectedBlock=false;
    return source.split(/(<[^>]*>)/g).map(part=>{
      if(part.startsWith('<')) {
        if(/^<(?:script|style)\b/i.test(part))protectedBlock=true;
        if(/^<\/(?:script|style)\b/i.test(part))protectedBlock=false;
        return part.replace(/\b(placeholder|title|aria-label)=(['"])(.*?)\2/g,(all,attr,quote,copy)=>
          copy.includes('\uE000')?all:`${attr}=${quote}${t(copy).replace(/"/g,'&quot;').replace(/'/g,'&#39;')}${quote}`);
      }
      return protectedBlock ? part : pattern(part);
    }).join('');
  }
  function template(strings,values,html) {
    let source=strings.map((s,i)=>s+(i<values.length?`\uE000${i}\uE001`:'')).join('');
    source=html?markup(source):pattern(source);
    return source.replace(/\uE000(\d+)\uE001/g,(_,i,offset)=>{
      const value=values[Number(i)];
      if(value?.__riggoDisplay){const before=source.slice(0,offset);return String(html&&before.lastIndexOf('<')>before.lastIndexOf('>')?value.original:value.localized);}
      return String(value??'');
    });
  }
  const api={
    t, display:value=>value?.__riggoDisplay?value:({__riggoDisplay:true,original:value,localized:t(value)}), h:(strings,...values)=>template(strings,values,true),
    msg:(strings,...values)=>template(strings,values,false), literal:markup,
    locale:()=>language==='en'?'en-US':'es-CO',
    get language(){return language},
    setLanguage(value){language=value==='en'?'en':'es';document.documentElement.lang=language;},
    missing:()=>[...missing], clearMissing:()=>missing.clear()
  };
  window.RigGOI18n=api;
  document.documentElement.lang=language;
  for(const name of ['alert','confirm']){
    const original=window[name].bind(window);window[name]=message=>original(t(message));
  }
})();
