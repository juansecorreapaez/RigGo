# RigGO 12.4.2

Build: `2026-10-14-1242-A1`. Base: RigGO 12.4.1 del entorno del usuario.

## Cambios

- Inglés y español: el primer ingreso autorizado pide elegir idioma; los ingresos siguientes recuperan la preferencia. Un selector en la barra superior permite cambiarla. La preferencia se guarda por usuario en Supabase Auth y se conserva localmente mientras no haya conexión. Los pendientes se sincronizan únicamente bajo la cuenta correspondiente.
- Se traducen las pantallas de planificación, ejecución, administración y Performance, mensajes y reportes generados. Los nombres, comentarios, descripciones, datos del Excel e identificadores operativos conservan el contenido aportado por el usuario. Cambiar idioma conserva los campos en edición y los estados de ejecución.
- Arranque compatible con versiones superiores de IndexedDB y almacenes faltantes; reintento limitado para errores transitorios, identificación del error y reintento sin borrar planes, evidencias ni colas. El arranque espera a que terminen de cargar los módulos y no depende de completar una actualización del Service Worker.
- M48 distingue período real, tiempo de operación desde la liberación real, tiempo del plan al corte y retraso de liberación. Ejemplo: liberación planificada 12:00, real 21:00 y corte 00:00: 3 horas reales, 12 horas del plan y 9 horas de retraso. La línea base se conserva.
- Transporte muestra cargadas acumuladas, pendientes de salir, en tránsito y posicionadas. Al terminar 54 cargas: 54 acumuladas, 0 pendientes de salir, 0 en tránsito y 54 posicionadas. Se conserva RM físico = posicionadas / total y los ajustes del supervisor.

## Publicar en Cloudflare Pages

1. Publicar el contenido de la raíz con `index.html`, `sw.js`, `version.json`, `_headers`, `manifest.webmanifest` y `assets/`. No requiere compilación ni instalación de paquetes.
2. Mantener el origen/dominio existente. No borrar los datos del sitio para actualizar.
3. Comprobar el título **RigGO · 12.4.2** y build `2026-10-14-1242-A1`.
4. Con una cuenta autorizada, elegir idioma, salir y volver; comprobarlo también en otro dispositivo. Cambiar idioma durante una edición y verificar el reporte.
5. Validar el arranque en la instalación Edge afectada y verificar M48, transporte, desplazamiento, fotos/firma y operación offline antes de extender el despliegue.

La preferencia usa los metadatos de Supabase Auth del usuario (`riggo_language`, `riggo_language_selected`, `riggo_language_updated_at`). No requiere SQL ni nuevos permisos administrativos. Esta entrega no se desplegó ni se enviaron correos reales. SANAD queda fuera de este cambio.

## Validación

Véase `docs/VALIDATION_12.4.2.md`. Las pruebas ejecutan el código y almacenamiento reales con servicios externos aislados. Incluyen los 29 grupos operativos existentes y los escenarios de idioma, varias cuentas, nuevo dispositivo, edición, colas offline y recuperación del almacenamiento. Los perfiles Edge/Brave de Chromium no sustituyen probar las instalaciones reales afectadas.
