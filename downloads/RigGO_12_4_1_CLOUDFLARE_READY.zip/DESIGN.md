# RigGO · Diseño operativo

La 12.4 refina la identidad existente: fotografía real del equipo, logotipos Nabors/RigGO y superficies oscuras para una herramienta de movilización. El propósito es registrar y revisar operación, no presentar una campaña comercial.

## Tipografía y jerarquía

Segoe UI Variable Text / Segoe UI / fuente del sistema. Roles estables en escritorio y móvil: cuerpo y campos 16 px, etiquetas/controles/tablas 14 px, metadatos 12 px. Los valores están expresados en rem para permitir ampliación de texto. Títulos de 18–32 px según función y los titulares de marca existentes se mantienen.

Las plantillas oficiales OPS usan sus dimensiones de impresión en puntos y milímetros. Las fuentes de correo/PDF conservan fallbacks compatibles con exportación. No se introduce otra fuente remota.

## Composición

Operación primero: estado, período, actividad y siguiente acción. Los paneles se usan para separar tareas; las subdivisiones internas emplean espacios y líneas. El resumen de Performance utiliza valores con etiquetas y contexto en lugar de anillos decorativos.

En móvil, tarjetas de transporte, campos de participantes y rutas se apilan. La navegación de pasos puede desplazarse horizontalmente y mantiene visible el paso activo. Las tablas extensas conservan desplazamiento horizontal dentro de su contenedor. Las gráficas ajustan su ancho y reducen la frecuencia de etiquetas, manteniendo tamaño legible.

## Estados y accesibilidad

Foco visible, enlace para saltar al contenido, acciones desde teclado, etiquetas de participantes y archivos, selección/cursor/barra de desplazamiento acordes con la paleta. Los diálogos conservan foco y responden a Escape. Los errores distinguen guardado local, sincronización pendiente y fallo de almacenamiento. Movimiento reducido respeta la preferencia del dispositivo.

## Validación con Impeccable

Se aplicaron typeset y harden, dos evaluaciones tipográficas independientes y el detector completo. Una revisión conjunta de escritorio/móvil identificó los defectos; se corrigieron en una sola tanda y se realizó una ronda de confirmación. El detector estático también ve reglas de capas históricas de CSS: su informe se evalúa junto con los estilos computados, no se presenta como garantía de accesibilidad completa.

## Correcciones 12.4.1

Se mantiene la identidad de la 12.4. El documento puede crecer y desplazarse en móvil y escritorio; la navegación de ejecución permanece al final del contenido. Transporte etiqueta cargadas, movilizadas y posicionadas, con el RM físico identificado. El contexto de horas y referencia del plan acompaña la comparación.
